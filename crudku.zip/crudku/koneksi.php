<?php
$host = 'localhost';
$username = 'root';
$password = '';
$db_name = 'ikidatabase'; // nama databasenya
$conn = new mysqli($host, $username, $password, $db_name);
?>
